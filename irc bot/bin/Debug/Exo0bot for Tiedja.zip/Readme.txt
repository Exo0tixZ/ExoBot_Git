Commands:
--!rps {action}
 -{action}= Rock, Paper, Scissors

--!np
 -Tells the stream what song is currently being played

--{osulink}
 -Tells the stream their request has been delivered; Tells you via ingame chat who requested and which song

--------------------------------------------------------------
For more commands just message me!

Also, there is a bug.. if you press the disconnect button it actually doesnt disconnect and still runs on both Osu and twitch servers.
so DON'T PRESS THAT BUTTON UNTIL I CAN FIX THAT ;w;